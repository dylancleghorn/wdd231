// Home page interactions: weather + random spotlights
// NOTE: Replace 'YOUR_OPENWEATHERMAP_API_KEY' with your actual API key.
const OPENWEATHER_API_KEY = "YOUR_OPENWEATHERMAP_API_KEY"; // <-- put your key here
const CITY_NAME = "Dallas";
const UNITS = "imperial"; // 'imperial' for °F, 'metric' for °C

// Members JSON path (reused from directory data)
const MEMBERS_JSON_URL = "data/members.json";

// Utils
function byId(id) { return document.getElementById(id); }

// ============ Weather ============
async function loadWeather() {
  if (!OPENWEATHER_API_KEY || OPENWEATHER_API_KEY === "YOUR_OPENWEATHERMAP_API_KEY") {
    console.warn("Add your OpenWeatherMap API key to enable live weather.");
    return;
  }
  try {
    // Geocoding for Dallas, TX (or you can hardcode lat/lon for Dallas: 32.7767, -96.7970)
    const lat = 32.7767;
    const lon = -96.7970;

    // Current weather
    const currentUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=${UNITS}&appid=${OPENWEATHER_API_KEY}`;
    const currentRes = await fetch(currentUrl);
    if (!currentRes.ok) throw new Error("Weather current fetch failed");
    const current = await currentRes.json();

    // Update UI
    const temp = Math.round(current.main.temp);
    const desc = current.weather?.[0]?.description ?? "—";
    const wind = Math.round(current.wind?.speed ?? 0);
    const humidity = Math.round(current.main?.humidity ?? 0);

    const tempEl = byId("weather-temp");
    const descEl = byId("weather-desc");
    const metaEl = byId("weather-meta");
    if (tempEl) tempEl.textContent = `${temp}°`;
    if (descEl) descEl.textContent = desc.charAt(0).toUpperCase() + desc.slice(1);
    if (metaEl) metaEl.textContent = `Wind: ${wind} mph • Humidity: ${humidity}%`;

    // Forecast (3-day)
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=${UNITS}&appid=${OPENWEATHER_API_KEY}`;
    const forecastRes = await fetch(forecastUrl);
    if (!forecastRes.ok) throw new Error("Forecast fetch failed");
    const forecastData = await forecastRes.json();

    // OpenWeather 5-day / 3-hour forecast: pick the next three noons
    const forecastList = forecastData.list ?? [];
    const days = [];

    for (const item of forecastList) {
      const dt = new Date(item.dt * 1000);
      const hour = dt.getUTCHours(); // we won't be precise about local noon; sample every ~24h after first
      // take every ~24h window's first item (simpler approach)
      if (days.length === 0 || (dt - days[days.length - 1].date) > 20 * 60 * 60 * 1000) {
        days.push({ date: dt, temp: Math.round(item.main.temp), desc: item.weather?.[0]?.description ?? "—" });
      }
      if (days.length >= 3) break;
    }

    const forecastEl = byId("forecast-list");
    if (forecastEl) {
      forecastEl.innerHTML = "";
      days.forEach(d => {
        const li = document.createElement("li");
        const label = d.date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
        const descLabel = d.desc.charAt(0).toUpperCase() + d.desc.slice(1);
        li.textContent = `${label}: ${d.temp}° — ${descLabel}`;
        forecastEl.appendChild(li);
      });
    }
  } catch (err) {
    console.error(err);
  }
}

// ============ Spotlights ============
function pickRandom(arr, count) {
  const copy = arr.slice();
  const result = [];
  while (copy.length && result.length < count) {
    const i = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(i, 1)[0]);
  }
  return result;
}

function createSpotlightCard(member) {
  const card = document.createElement("article");
  card.className = "card spotlight";
  card.setAttribute("role", "listitem");

  const img = document.createElement("img");
  img.alt = member.name || "Company logo";
  img.loading = "lazy";
  img.decoding = "async";
  img.src = member.logo || member.image || "";
  card.appendChild(img);

  const h4 = document.createElement("h4");
  h4.textContent = member.name || "Company";
  card.appendChild(h4);

  const info = document.createElement("p");
  info.innerHTML = [
    member.phone ? `<strong>Phone:</strong> ${member.phone}` : "",
    member.address ? `<br><strong>Address:</strong> ${member.address}` : "",
    member.website ? `<br><a href="${member.website}" target="_blank" rel="noopener">Website</a>` : ""
  ].join("");
  card.appendChild(info);

  const level = document.createElement("div");
  level.className = "badge";
  level.textContent = (member.membershipLevel || member.membership || member.level || "").toString();
  card.appendChild(level);

  return card;
}

async function loadSpotlights() {
  try {
    const res = await fetch(MEMBERS_JSON_URL);
    if (!res.ok) throw new Error("Failed to load members JSON");
    const data = await res.json();

    // Normalize array
    const members = Array.isArray(data) ? data : (data.members || data.directory || []);

    // Filter gold/silver
    const premium = members.filter(m => {
      const lv = (m.membershipLevel || m.membership || m.level || "").toLowerCase();
      return lv.includes("gold") || lv.includes("silver");
    });

    // Pick 2 or 3 spotlights at random
    const count = Math.random() < 0.5 ? 2 : 3;
    const picks = pickRandom(premium, count);

    const grid = document.getElementById("spotlight-grid");
    if (grid) {
      grid.innerHTML = "";
      picks.forEach(m => grid.appendChild(createSpotlightCard(m)));
    }
  } catch (err) {
    console.error(err);
  }
}

// ============ Footer year ============
function setYear() {
  const y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();
}

document.addEventListener("DOMContentLoaded", () => {
  setYear();
  loadWeather();
  loadSpotlights();
});
